from .interlo import Objectset
from .interlo import Starset
from .interlo import ISOset 